# StudySA AI — Android / Google Play project

This Android Studio project wraps the live StudySA AI web app as a native Android application shell.

Live app:
https://studysa-ai-z3dlb1.v2.appdeploy.ai/

## Google Play configuration
- Application ID: `com.studysa.ai`
- Version code: `1`
- Version name: `1.0.0`
- Compile SDK: 36
- Target SDK: 36
- Minimum SDK: 23
- Release format: Android App Bundle (`.aab`)

## Build in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Create your release signing key in Android Studio (Build > Generate Signed Bundle / APK).
4. Choose **Android App Bundle**.
5. Build the signed release bundle.
6. Upload the resulting `.aab` to Google Play Console.

## Important
The web app remains hosted by AppDeploy, so this wrapper requires an internet connection. The StudySA AI backend and AI features remain on the live service.

Before production submission, test sign-in, AI homework, camera/photo scanning, quizzes, navigation, and back-button behavior on several Android devices.

You should also prepare:
- app icon / Play listing graphics
- privacy policy URL
- Data safety answers
- content rating
- target-audience declaration
- store listing screenshots and description
- support email

For new personal Play Console accounts created after Nov 13, 2023, Google currently requires a closed test with at least 12 opted-in testers continuously for 14 days before production access.